# Enter the number from the user and depending on whether the number is even or
# odd, print out an appropriate message to the user.


num = int(input("Enter a number: "))
if num % 2 == 0:
    print("The number is even")
else:
    print("The number is odd")
