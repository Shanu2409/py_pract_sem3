# reverse of a string

def reverse(s):
    print(s[::-1])


reverse(input("Enter a string: "))
