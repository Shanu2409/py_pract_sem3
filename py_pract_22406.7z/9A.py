from tkinter import *
from tkinter.font import families

root = Tk()

l1 = Label(root, text='hello', font=('arial bold', 50), bg='red')
l1.place(relx=0.5, rely=0.5, anchor=CENTER)

root.mainloop()
