a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
print(a)

a.pop(0)
a.pop(2)
a.pop(4)
a.pop(5)

print(a)
