file = open("some.txt", "r")
lines = file.readlines()

for i in lines:
    print(i)
