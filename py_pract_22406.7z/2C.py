# Define a procedure histogram() that takes a list of integers and prints a
# histogram to the screen.

def histogram(a, b, c):
    for i in range(a):
        print('*', end='')

    print()
    for i in range(b):
        print('*', end='')

    print()
    for i in range(c):
        print('*', end='')


histogram(3, 77, 5)
