dic = {1: 11, 2: 22, 3: 33}

lis = dic.values()

ans = 0

for i in lis:
    ans += i

print(ans)
