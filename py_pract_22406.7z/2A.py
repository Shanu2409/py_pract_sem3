# return true if vowels

def isVowels(s):
    if s.lower() == 'a' or s.lower() == 'e' or s.lower() == 'i' or s.lower() == 'o' or s.lower() == 'u':
        return True
    else:
        return False


ch = input("Enter a char : ")

if isVowels(ch):
    print("It's a Vowels...")
else:
    print("It's not a Vowels")
