# create function to return the len of string or list

def length(x):
    return len(x)


str = "hello my name is shanu"
lis = (1, 2, 3, 4, 5)

print(length(lis))
