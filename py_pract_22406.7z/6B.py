# append a text and display the file

file = open("some.txt", "a+")

txt = input("Enter a text to append in some.txt : ")

file.write('\n\n\n' + txt)

file.close()
