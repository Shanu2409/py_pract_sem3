# check for armstrong number and palindrome number

num = int(input("Enter a number for armstrong : "))
temp = num
sum = 0

while temp > 0:
    digit = temp % 10
    sum = sum + digit ** 3
    temp = temp // 10

if num == sum:
    print(num, "is an Armstrong number")
else:
    print(num, "is not an Armstrong number")

num = int(input("Enter a number for palindrome : "))
temp = num
rev = 0

while temp > 0:
    dig = temp % 10
    rev = (rev * 10) + dig
    temp = temp // 10

if num == rev:
    print("Number is palindrome")
else:
    print("it's not palindrome")
