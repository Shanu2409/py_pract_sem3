# copy a list

a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
print("a = ", a)

b = a.copy()

print("b = ", b)
