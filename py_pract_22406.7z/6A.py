file = open('some.txt', 'r')

print(file.read())

file.close()
