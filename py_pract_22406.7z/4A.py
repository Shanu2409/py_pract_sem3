# Write a program that takes two lists and returns True if they have at least one
# common member.

a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
b = [22, 43, 643, 14]

for i in b:
    if i in a:
        print(i, "similar in both list")
